(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.2a302d37.js")
    );
  })().catch(console.error);

})();
