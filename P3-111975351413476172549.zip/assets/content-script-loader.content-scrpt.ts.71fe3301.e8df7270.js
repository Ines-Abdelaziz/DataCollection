(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.71fe3301.js")
    );
  })().catch(console.error);

})();
