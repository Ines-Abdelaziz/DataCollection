(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.82014094.js")
    );
  })().catch(console.error);

})();
