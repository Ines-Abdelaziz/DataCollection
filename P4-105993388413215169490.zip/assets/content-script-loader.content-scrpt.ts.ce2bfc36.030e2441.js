(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.ce2bfc36.js")
    );
  })().catch(console.error);

})();
