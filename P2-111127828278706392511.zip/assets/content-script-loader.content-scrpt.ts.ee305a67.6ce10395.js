(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.ee305a67.js")
    );
  })().catch(console.error);

})();
