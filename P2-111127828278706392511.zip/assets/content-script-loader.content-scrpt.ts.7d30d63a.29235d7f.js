(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-scrpt.ts.7d30d63a.js")
    );
  })().catch(console.error);

})();
